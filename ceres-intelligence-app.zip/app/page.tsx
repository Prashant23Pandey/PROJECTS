import { AppProvider } from "@/lib/app-context"
import { CeresApp } from "@/components/ceres-app"

export default function Home() {
  return (
    <AppProvider>
      <CeresApp />
    </AppProvider>
  )
}
