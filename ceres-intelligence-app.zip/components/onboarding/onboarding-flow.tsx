"use client"

import { useState } from "react"
import { useApp, FarmerProfile } from "@/lib/app-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { 
  Sprout, 
  Phone, 
  Globe, 
  MapPin, 
  Award,
  Wheat,
  ArrowRight,
  ArrowLeft,
  Check
} from "lucide-react"

const languages = [
  { code: "en", name: "English" },
  { code: "hi", name: "Hindi" },
  { code: "mr", name: "Marathi" },
  { code: "ta", name: "Tamil" },
  { code: "te", name: "Telugu" },
  { code: "kn", name: "Kannada" },
]

const experienceLevels = [
  { value: "beginner", label: "Beginner", icon: "seedling" },
  { value: "2+", label: "2+ Years", icon: "sprout" },
  { value: "5+", label: "5+ Years", icon: "tree" },
  { value: "10+", label: "10+ Years", icon: "mountain" },
] as const

const crops = [
  "Rice", "Wheat", "Cotton", "Sugarcane", "Maize", 
  "Soybean", "Groundnut", "Vegetables", "Fruits", "Pulses"
]

export function OnboardingFlow() {
  const { setIsOnboarded, setFarmerProfile } = useApp()
  const [step, setStep] = useState(0)
  const [formData, setFormData] = useState<Partial<FarmerProfile>>({
    name: "",
    phone: "",
    language: "en",
    location: { village: "", district: "", state: "" },
    experience: "beginner",
    crops: [],
    farmSize: "",
    soilType: "",
    irrigationMethod: "",
  })

  const totalSteps = 5

  const handleNext = () => {
    if (step < totalSteps - 1) {
      setStep(step + 1)
    } else {
      setFarmerProfile(formData as FarmerProfile)
      setIsOnboarded(true)
    }
  }

  const handleBack = () => {
    if (step > 0) {
      setStep(step - 1)
    }
  }

  const updateFormData = (updates: Partial<FarmerProfile>) => {
    setFormData({ ...formData, ...updates })
  }

  const toggleCrop = (crop: string) => {
    const currentCrops = formData.crops || []
    if (currentCrops.includes(crop)) {
      updateFormData({ crops: currentCrops.filter(c => c !== crop) })
    } else {
      updateFormData({ crops: [...currentCrops, crop] })
    }
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="bg-primary px-6 pt-12 pb-8 text-primary-foreground">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-full bg-primary-foreground/20 flex items-center justify-center">
            <Sprout className="w-7 h-7" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Ceres Intelligence</h1>
            <p className="text-sm opacity-90">Smart Farming Assistant</p>
          </div>
        </div>
        
        {/* Progress bar */}
        <div className="flex gap-2 mt-6">
          {Array.from({ length: totalSteps }).map((_, i) => (
            <div 
              key={i}
              className={`h-2 flex-1 rounded-full transition-colors ${
                i <= step ? "bg-primary-foreground" : "bg-primary-foreground/30"
              }`}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 py-8 overflow-auto">
        {step === 0 && (
          <WelcomeStep 
            name={formData.name || ""} 
            phone={formData.phone || ""}
            onNameChange={(name) => updateFormData({ name })}
            onPhoneChange={(phone) => updateFormData({ phone })}
          />
        )}
        
        {step === 1 && (
          <LanguageStep 
            selected={formData.language || "en"}
            onSelect={(language) => updateFormData({ language })}
          />
        )}
        
        {step === 2 && (
          <LocationStep 
            location={formData.location || { village: "", district: "", state: "" }}
            onUpdate={(location) => updateFormData({ location })}
          />
        )}
        
        {step === 3 && (
          <ExperienceStep 
            selected={formData.experience || "beginner"}
            onSelect={(experience) => updateFormData({ experience })}
          />
        )}
        
        {step === 4 && (
          <CropsStep 
            selectedCrops={formData.crops || []}
            onToggle={toggleCrop}
            farmSize={formData.farmSize || ""}
            onFarmSizeChange={(farmSize) => updateFormData({ farmSize })}
          />
        )}
      </div>

      {/* Navigation */}
      <div className="px-6 pb-8 pt-4 bg-background border-t border-border">
        <div className="flex gap-4">
          {step > 0 && (
            <Button 
              variant="outline" 
              size="lg"
              onClick={handleBack}
              className="flex-1 h-14 text-lg"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back
            </Button>
          )}
          <Button 
            size="lg"
            onClick={handleNext}
            className="flex-1 h-14 text-lg"
            disabled={step === 0 && (!formData.name || !formData.phone)}
          >
            {step === totalSteps - 1 ? (
              <>
                <Check className="w-5 h-5 mr-2" />
                Start Farming
              </>
            ) : (
              <>
                Next
                <ArrowRight className="w-5 h-5 ml-2" />
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}

function WelcomeStep({ 
  name, 
  phone,
  onNameChange, 
  onPhoneChange 
}: { 
  name: string
  phone: string
  onNameChange: (name: string) => void
  onPhoneChange: (phone: string) => void
}) {
  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="w-24 h-24 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
          <Wheat className="w-12 h-12 text-primary" />
        </div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Welcome, Farmer!</h2>
        <p className="text-muted-foreground text-lg">Let us help you grow better crops</p>
      </div>
      
      <div className="space-y-6">
        <div className="space-y-3">
          <label className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Award className="w-5 h-5 text-primary" />
            Your Name
          </label>
          <Input 
            type="text"
            placeholder="Enter your name"
            value={name}
            onChange={(e) => onNameChange(e.target.value)}
            className="h-14 text-lg px-4"
          />
        </div>
        
        <div className="space-y-3">
          <label className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Phone className="w-5 h-5 text-primary" />
            Phone Number
          </label>
          <Input 
            type="tel"
            placeholder="Enter phone number"
            value={phone}
            onChange={(e) => onPhoneChange(e.target.value)}
            className="h-14 text-lg px-4"
          />
        </div>
      </div>
    </div>
  )
}

function LanguageStep({ 
  selected, 
  onSelect 
}: { 
  selected: string
  onSelect: (language: string) => void
}) {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <div className="w-20 h-20 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
          <Globe className="w-10 h-10 text-primary" />
        </div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Choose Language</h2>
        <p className="text-muted-foreground text-lg">Select your preferred language</p>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        {languages.map((lang) => (
          <button
            key={lang.code}
            onClick={() => onSelect(lang.code)}
            className={`p-6 rounded-2xl border-2 text-center transition-all ${
              selected === lang.code 
                ? "border-primary bg-primary/10 text-primary" 
                : "border-border bg-card text-foreground hover:border-primary/50"
            }`}
          >
            <span className="text-xl font-semibold">{lang.name}</span>
          </button>
        ))}
      </div>
    </div>
  )
}

function LocationStep({ 
  location, 
  onUpdate 
}: { 
  location: { village: string; district: string; state: string }
  onUpdate: (location: { village: string; district: string; state: string }) => void
}) {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <div className="w-20 h-20 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
          <MapPin className="w-10 h-10 text-primary" />
        </div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Your Location</h2>
        <p className="text-muted-foreground text-lg">Helps us provide local weather & tips</p>
      </div>
      
      <div className="space-y-5">
        <div className="space-y-2">
          <label className="text-lg font-semibold text-foreground">Village</label>
          <Input 
            type="text"
            placeholder="Enter village name"
            value={location.village}
            onChange={(e) => onUpdate({ ...location, village: e.target.value })}
            className="h-14 text-lg px-4"
          />
        </div>
        
        <div className="space-y-2">
          <label className="text-lg font-semibold text-foreground">District</label>
          <Input 
            type="text"
            placeholder="Enter district"
            value={location.district}
            onChange={(e) => onUpdate({ ...location, district: e.target.value })}
            className="h-14 text-lg px-4"
          />
        </div>
        
        <div className="space-y-2">
          <label className="text-lg font-semibold text-foreground">State</label>
          <Input 
            type="text"
            placeholder="Enter state"
            value={location.state}
            onChange={(e) => onUpdate({ ...location, state: e.target.value })}
            className="h-14 text-lg px-4"
          />
        </div>
      </div>
    </div>
  )
}

function ExperienceStep({ 
  selected, 
  onSelect 
}: { 
  selected: string
  onSelect: (experience: "beginner" | "2+" | "5+" | "10+") => void
}) {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <div className="w-20 h-20 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
          <Award className="w-10 h-10 text-primary" />
        </div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Farming Experience</h2>
        <p className="text-muted-foreground text-lg">How long have you been farming?</p>
      </div>
      
      <div className="space-y-4">
        {experienceLevels.map((level) => (
          <button
            key={level.value}
            onClick={() => onSelect(level.value)}
            className={`w-full p-5 rounded-2xl border-2 flex items-center gap-4 transition-all ${
              selected === level.value 
                ? "border-primary bg-primary/10" 
                : "border-border bg-card hover:border-primary/50"
            }`}
          >
            <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${
              selected === level.value ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
            }`}>
              <Sprout className="w-7 h-7" />
            </div>
            <span className={`text-xl font-semibold ${
              selected === level.value ? "text-primary" : "text-foreground"
            }`}>
              {level.label}
            </span>
            {selected === level.value && (
              <Check className="w-6 h-6 text-primary ml-auto" />
            )}
          </button>
        ))}
      </div>
    </div>
  )
}

function CropsStep({ 
  selectedCrops, 
  onToggle,
  farmSize,
  onFarmSizeChange
}: { 
  selectedCrops: string[]
  onToggle: (crop: string) => void
  farmSize: string
  onFarmSizeChange: (size: string) => void
}) {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <div className="w-20 h-20 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
          <Wheat className="w-10 h-10 text-primary" />
        </div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Your Crops</h2>
        <p className="text-muted-foreground text-lg">Select crops you grow (optional)</p>
      </div>
      
      <div className="space-y-2">
        <label className="text-lg font-semibold text-foreground">Farm Size (acres)</label>
        <Input 
          type="text"
          placeholder="e.g., 5 acres"
          value={farmSize}
          onChange={(e) => onFarmSizeChange(e.target.value)}
          className="h-14 text-lg px-4"
        />
      </div>
      
      <div className="flex flex-wrap gap-3">
        {crops.map((crop) => (
          <button
            key={crop}
            onClick={() => onToggle(crop)}
            className={`px-5 py-3 rounded-full border-2 text-lg font-medium transition-all ${
              selectedCrops.includes(crop) 
                ? "border-primary bg-primary text-primary-foreground" 
                : "border-border bg-card text-foreground hover:border-primary/50"
            }`}
          >
            {crop}
          </button>
        ))}
      </div>
    </div>
  )
}
