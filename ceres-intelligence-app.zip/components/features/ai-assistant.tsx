"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { 
  ArrowLeft, 
  MessageCircle,
  Send,
  Mic,
  MicOff,
  Bot,
  User,
  Lightbulb
} from "lucide-react"

interface AIAssistantProps {
  onBack: () => void
}

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

const suggestedQuestions = [
  "When should I water my rice crops?",
  "How to control aphids naturally?",
  "Best fertilizer for wheat?",
  "Signs of nitrogen deficiency?",
]

export function AIAssistant({ onBack }: AIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "Hello! I am your AI farming assistant. Ask me anything about farming, crops, soil, pests, or weather. I am here to help you grow better!",
      timestamp: new Date()
    }
  ])
  const [input, setInput] = useState("")
  const [isListening, setIsListening] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = (text: string = input) => {
    if (!text.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: text,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    // Simulate AI response
    setTimeout(() => {
      const responses: { [key: string]: string } = {
        "water": "For rice crops, water when the soil moisture drops below 70%. In the current dry season, water every 2-3 days. Early morning (6-8 AM) is the best time for irrigation.",
        "aphid": "To control aphids naturally: 1) Spray neem oil solution (2ml per liter water), 2) Introduce ladybugs, 3) Use garlic-chili spray, 4) Plant marigolds nearby as they repel aphids.",
        "fertilizer": "For wheat, use NPK 120:60:40 kg/ha. Apply nitrogen in 3 splits: 50% at sowing, 25% at tillering, and 25% at heading stage. Add zinc if your soil test shows deficiency.",
        "nitrogen": "Signs of nitrogen deficiency: 1) Yellowing of older leaves first, 2) Stunted growth, 3) Light green leaf color, 4) Poor tillering. Apply urea at 50 kg/ha as foliar spray.",
      }

      let responseText = "Based on your question, I recommend consulting with your local agricultural extension office for specific advice tailored to your region and soil conditions. Would you like me to provide general guidance on this topic?"
      
      for (const [keyword, response] of Object.entries(responses)) {
        if (text.toLowerCase().includes(keyword)) {
          responseText = response
          break
        }
      }

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: responseText,
        timestamp: new Date()
      }

      setMessages(prev => [...prev, assistantMessage])
      setIsTyping(false)
    }, 1500)
  }

  const toggleListening = () => {
    setIsListening(!isListening)
    // Voice recognition would be implemented here
    if (!isListening) {
      setTimeout(() => {
        setIsListening(false)
        setInput("How to control pests in my cotton crop?")
      }, 2000)
    }
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="bg-primary px-6 pt-12 pb-6">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="w-12 h-12 rounded-full bg-primary-foreground/20 flex items-center justify-center"
          >
            <ArrowLeft className="w-6 h-6 text-primary-foreground" />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-primary-foreground/20 flex items-center justify-center">
              <MessageCircle className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-primary-foreground">AI Assistant</h1>
              <p className="text-primary-foreground/80 text-sm">Ask any farming question</p>
            </div>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-auto px-4 py-6 space-y-4">
        {messages.map((message) => (
          <div 
            key={message.id}
            className={`flex gap-3 ${message.role === "user" ? "flex-row-reverse" : ""}`}
          >
            <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
              message.role === "assistant" ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"
            }`}>
              {message.role === "assistant" ? (
                <Bot className="w-5 h-5" />
              ) : (
                <User className="w-5 h-5" />
              )}
            </div>
            <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
              message.role === "assistant" 
                ? "bg-card border border-border" 
                : "bg-primary text-primary-foreground"
            }`}>
              <p className={message.role === "assistant" ? "text-foreground" : ""}>
                {message.content}
              </p>
            </div>
          </div>
        ))}
        
        {isTyping && (
          <div className="flex gap-3">
            <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center">
              <Bot className="w-5 h-5" />
            </div>
            <div className="bg-card border border-border rounded-2xl px-4 py-3">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" />
                <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "0.1s" }} />
                <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "0.2s" }} />
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Questions */}
      {messages.length === 1 && (
        <div className="px-4 pb-4">
          <div className="flex items-center gap-2 mb-3">
            <Lightbulb className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Suggested questions</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {suggestedQuestions.map((question, index) => (
              <button
                key={index}
                onClick={() => handleSend(question)}
                className="px-4 py-2 bg-secondary text-secondary-foreground rounded-full text-sm hover:bg-secondary/80 transition-colors"
              >
                {question}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="border-t border-border bg-background px-4 py-4">
        <div className="flex gap-3">
          <button
            onClick={toggleListening}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
              isListening 
                ? "bg-destructive text-destructive-foreground animate-pulse" 
                : "bg-secondary text-secondary-foreground"
            }`}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>
          <div className="flex-1 flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your question..."
              className="h-12 text-base"
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
            />
            <Button 
              size="lg" 
              className="h-12 w-12 p-0"
              onClick={() => handleSend()}
              disabled={!input.trim()}
            >
              <Send className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
