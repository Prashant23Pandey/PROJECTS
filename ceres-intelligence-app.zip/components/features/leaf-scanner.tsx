"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { 
  Leaf, 
  ArrowLeft, 
  Camera,
  Upload,
  AlertTriangle,
  Check,
  X,
  Lightbulb
} from "lucide-react"

interface LeafScannerProps {
  onBack: () => void
}

interface ScanResult {
  disease: string | null
  confidence: number
  healthy: boolean
  treatment: string[]
  prevention: string[]
}

export function LeafScanner({ onBack }: LeafScannerProps) {
  const [image, setImage] = useState<string | null>(null)
  const [isScanning, setIsScanning] = useState(false)
  const [result, setResult] = useState<ScanResult | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setImage(reader.result as string)
        setResult(null)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleScan = () => {
    setIsScanning(true)
    // Simulate AI analysis
    setTimeout(() => {
      setResult({
        disease: "Leaf Blight",
        confidence: 89,
        healthy: false,
        treatment: [
          "Apply copper-based fungicide",
          "Remove infected leaves",
          "Improve air circulation"
        ],
        prevention: [
          "Avoid overhead watering",
          "Maintain proper spacing",
          "Use disease-resistant varieties"
        ]
      })
      setIsScanning(false)
    }, 2500)
  }

  const resetScan = () => {
    setImage(null)
    setResult(null)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary px-6 pt-12 pb-6">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="w-12 h-12 rounded-full bg-primary-foreground/20 flex items-center justify-center"
          >
            <ArrowLeft className="w-6 h-6 text-primary-foreground" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-primary-foreground">Leaf Health Scanner</h1>
            <p className="text-primary-foreground/80">Detect diseases & pests</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-6 space-y-6">
        {!image ? (
          /* Upload Section */
          <div className="space-y-6">
            <div className="bg-card rounded-2xl border-2 border-dashed border-border p-8 text-center">
              <div className="w-20 h-20 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Leaf className="w-10 h-10 text-primary" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-2">Scan Your Leaf</h3>
              <p className="text-muted-foreground mb-6">Take a photo or upload an image of the leaf</p>
              
              <div className="space-y-3">
                <Button 
                  size="lg" 
                  className="w-full h-14 text-lg"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Camera className="w-5 h-5 mr-2" />
                  Take Photo
                </Button>
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="w-full h-14 text-lg"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="w-5 h-5 mr-2" />
                  Upload Image
                </Button>
              </div>
              
              <input 
                ref={fileInputRef}
                type="file" 
                accept="image/*" 
                capture="environment"
                onChange={handleImageUpload}
                className="hidden"
              />
            </div>

            {/* Tips */}
            <div className="bg-accent/30 rounded-2xl p-5">
              <h4 className="font-semibold text-accent-foreground mb-3 flex items-center gap-2">
                <Lightbulb className="w-5 h-5" />
                Tips for Best Results
              </h4>
              <ul className="space-y-2 text-accent-foreground/80 text-sm">
                <li>Use good lighting</li>
                <li>Capture the affected area clearly</li>
                <li>Include both healthy and diseased parts</li>
                <li>Hold camera steady</li>
              </ul>
            </div>
          </div>
        ) : (
          /* Image Preview & Results */
          <div className="space-y-6">
            {/* Image Preview */}
            <div className="relative rounded-2xl overflow-hidden">
              <img 
                src={image} 
                alt="Leaf scan" 
                className="w-full h-64 object-cover"
              />
              {!result && (
                <button 
                  onClick={resetScan}
                  className="absolute top-4 right-4 w-10 h-10 rounded-full bg-foreground/80 flex items-center justify-center"
                >
                  <X className="w-5 h-5 text-background" />
                </button>
              )}
            </div>

            {!result ? (
              /* Scan Button */
              <Button 
                size="lg" 
                className="w-full h-14 text-lg"
                onClick={handleScan}
                disabled={isScanning}
              >
                {isScanning ? (
                  <>
                    <div className="w-5 h-5 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2" />
                    Analyzing Leaf...
                  </>
                ) : (
                  <>
                    <Leaf className="w-5 h-5 mr-2" />
                    Start Scan
                  </>
                )}
              </Button>
            ) : (
              /* Results */
              <div className="space-y-5">
                {/* Status Card */}
                <div className={`rounded-2xl p-5 ${result.healthy ? "bg-good/10" : "bg-poor/10"}`}>
                  <div className="flex items-center gap-4 mb-4">
                    <div className={`w-14 h-14 rounded-full flex items-center justify-center ${
                      result.healthy ? "bg-good" : "bg-poor"
                    }`}>
                      {result.healthy ? (
                        <Check className="w-7 h-7 text-primary-foreground" />
                      ) : (
                        <AlertTriangle className="w-7 h-7 text-primary-foreground" />
                      )}
                    </div>
                    <div>
                      <h3 className={`text-xl font-bold ${result.healthy ? "text-good" : "text-poor"}`}>
                        {result.healthy ? "Healthy Leaf" : result.disease}
                      </h3>
                      <p className="text-muted-foreground">
                        {result.confidence}% confidence
                      </p>
                    </div>
                  </div>
                </div>

                {/* Treatment */}
                {!result.healthy && (
                  <div className="bg-card rounded-2xl p-5 border border-border">
                    <h4 className="font-bold text-foreground text-lg mb-4">Treatment</h4>
                    <ul className="space-y-3">
                      {result.treatment.map((item, index) => (
                        <li key={index} className="flex items-start gap-3">
                          <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0 mt-0.5">
                            <span className="text-xs font-bold text-primary-foreground">{index + 1}</span>
                          </div>
                          <span className="text-foreground">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Prevention */}
                <div className="bg-card rounded-2xl p-5 border border-border">
                  <h4 className="font-bold text-foreground text-lg mb-4">Prevention Tips</h4>
                  <ul className="space-y-3">
                    {result.prevention.map((item, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                        <span className="text-foreground">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Actions */}
                <div className="space-y-3 pb-6">
                  <Button 
                    size="lg" 
                    className="w-full h-14 text-lg"
                    onClick={resetScan}
                  >
                    Scan Another Leaf
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
