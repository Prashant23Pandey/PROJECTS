"use client"

import { useState } from "react"
import { 
  ArrowLeft, 
  DollarSign,
  TrendingUp,
  TrendingDown,
  Search,
  MapPin
} from "lucide-react"
import { Input } from "@/components/ui/input"

interface MarketPricesProps {
  onBack: () => void
}

interface CropPrice {
  crop: string
  price: number
  unit: string
  change: number
  market: string
}

export function MarketPrices({ onBack }: MarketPricesProps) {
  const [searchQuery, setSearchQuery] = useState("")

  const prices: CropPrice[] = [
    { crop: "Rice (Basmati)", price: 4200, unit: "quintal", change: 5.2, market: "APMC Mandi" },
    { crop: "Wheat", price: 2350, unit: "quintal", change: -2.1, market: "APMC Mandi" },
    { crop: "Cotton", price: 6800, unit: "quintal", change: 8.5, market: "Cotton Market" },
    { crop: "Sugarcane", price: 350, unit: "quintal", change: 0, market: "Sugar Mill" },
    { crop: "Soybean", price: 4500, unit: "quintal", change: 3.2, market: "APMC Mandi" },
    { crop: "Maize", price: 1950, unit: "quintal", change: -1.5, market: "APMC Mandi" },
    { crop: "Groundnut", price: 5200, unit: "quintal", change: 4.1, market: "APMC Mandi" },
    { crop: "Tomato", price: 2500, unit: "quintal", change: 12.5, market: "Vegetable Market" },
    { crop: "Onion", price: 1800, unit: "quintal", change: -8.2, market: "Vegetable Market" },
    { crop: "Potato", price: 1200, unit: "quintal", change: 2.3, market: "Vegetable Market" },
  ]

  const filteredPrices = prices.filter(p => 
    p.crop.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary px-6 pt-12 pb-6">
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={onBack}
            className="w-12 h-12 rounded-full bg-primary-foreground/20 flex items-center justify-center"
          >
            <ArrowLeft className="w-6 h-6 text-primary-foreground" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-primary-foreground">Market Prices</h1>
            <p className="text-primary-foreground/80">Current crop rates</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search crops..."
            className="h-14 pl-12 text-lg bg-primary-foreground"
          />
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-6">
        <div className="space-y-4">
          {filteredPrices.map((item, index) => (
            <div 
              key={index}
              className="bg-card rounded-2xl p-5 border border-border"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-bold text-foreground text-lg">{item.crop}</h3>
                  <div className="flex items-center gap-1 text-muted-foreground text-sm mt-1">
                    <MapPin className="w-4 h-4" />
                    <span>{item.market}</span>
                  </div>
                </div>
                <div className={`flex items-center gap-1 px-3 py-1 rounded-full text-sm font-semibold ${
                  item.change > 0 
                    ? "bg-good/20 text-good" 
                    : item.change < 0 
                      ? "bg-poor/20 text-poor"
                      : "bg-muted text-muted-foreground"
                }`}>
                  {item.change > 0 ? (
                    <TrendingUp className="w-4 h-4" />
                  ) : item.change < 0 ? (
                    <TrendingDown className="w-4 h-4" />
                  ) : null}
                  <span>{item.change > 0 ? "+" : ""}{item.change}%</span>
                </div>
              </div>
              
              <div className="flex items-end justify-between">
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-bold text-primary">Rs. {item.price.toLocaleString()}</span>
                  <span className="text-muted-foreground">/{item.unit}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Info */}
        <div className="mt-6 bg-accent/30 rounded-2xl p-5">
          <p className="text-accent-foreground/80 text-sm">
            Prices updated daily from local mandis. Actual prices may vary based on quality and quantity.
          </p>
        </div>
      </div>
    </div>
  )
}
