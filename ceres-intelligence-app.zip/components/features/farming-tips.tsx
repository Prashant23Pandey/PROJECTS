"use client"

import { useState } from "react"
import { 
  ArrowLeft, 
  BookOpen,
  Leaf,
  Bug,
  Droplets,
  Sprout,
  ChevronRight
} from "lucide-react"

interface FarmingTipsProps {
  onBack: () => void
}

interface TipCategory {
  id: string
  title: string
  icon: React.ReactNode
  tips: Tip[]
}

interface Tip {
  title: string
  content: string
}

export function FarmingTips({ onBack }: FarmingTipsProps) {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  const categories: TipCategory[] = [
    {
      id: "organic",
      title: "Organic Farming",
      icon: <Leaf className="w-7 h-7 text-primary" />,
      tips: [
        {
          title: "Make Natural Compost",
          content: "Mix kitchen waste, cow dung, and dried leaves. Keep moist and turn weekly. Ready in 2-3 months."
        },
        {
          title: "Green Manuring",
          content: "Grow legumes like dhaincha or sun hemp between seasons. Plough them back into soil for nitrogen."
        },
        {
          title: "Mulching Benefits",
          content: "Cover soil with straw or leaves. Reduces water loss, controls weeds, and adds nutrients."
        }
      ]
    },
    {
      id: "pest",
      title: "Pest Control",
      icon: <Bug className="w-7 h-7 text-primary" />,
      tips: [
        {
          title: "Neem Spray Solution",
          content: "Mix 500g neem leaves in 5L water overnight. Strain and spray on crops every 2 weeks."
        },
        {
          title: "Trap Crops",
          content: "Plant marigold or mustard around main crop. Pests attack these first, saving your crop."
        },
        {
          title: "Beneficial Insects",
          content: "Attract ladybugs and praying mantis by planting herbs. They eat harmful pests naturally."
        }
      ]
    },
    {
      id: "water",
      title: "Water Management",
      icon: <Droplets className="w-7 h-7 text-primary" />,
      tips: [
        {
          title: "Drip Irrigation",
          content: "Saves 50-70% water compared to flood irrigation. Water reaches roots directly with less evaporation."
        },
        {
          title: "Best Watering Time",
          content: "Water early morning (6-8 AM) or evening (4-6 PM). Avoid midday when evaporation is highest."
        },
        {
          title: "Rainwater Harvesting",
          content: "Build farm ponds to collect monsoon water. Use for irrigation during dry spells."
        }
      ]
    },
    {
      id: "soil",
      title: "Soil Health",
      icon: <Sprout className="w-7 h-7 text-primary" />,
      tips: [
        {
          title: "Crop Rotation",
          content: "Alternate between legumes and cereals each season. Legumes add nitrogen, cereals use it."
        },
        {
          title: "Earthworm Farming",
          content: "Earthworms improve soil structure and fertility. Add organic matter to attract them."
        },
        {
          title: "pH Balance",
          content: "Most crops need pH 6-7. Add lime for acidic soil, gypsum for alkaline soil."
        }
      ]
    }
  ]

  const selectedCategoryData = categories.find(c => c.id === selectedCategory)

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-primary px-6 pt-12 pb-6">
        <div className="flex items-center gap-4">
          <button 
            onClick={selectedCategory ? () => setSelectedCategory(null) : onBack}
            className="w-12 h-12 rounded-full bg-primary-foreground/20 flex items-center justify-center"
          >
            <ArrowLeft className="w-6 h-6 text-primary-foreground" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-primary-foreground">
              {selectedCategoryData ? selectedCategoryData.title : "Farming Tips"}
            </h1>
            <p className="text-primary-foreground/80">
              {selectedCategoryData ? "Learn best practices" : "Daily knowledge for better farming"}
            </p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-6">
        {!selectedCategory ? (
          /* Categories */
          <div className="space-y-4">
            <div className="bg-accent/30 rounded-2xl p-5 mb-6">
              <div className="flex items-center gap-3 mb-2">
                <BookOpen className="w-6 h-6 text-accent-foreground" />
                <h3 className="font-bold text-accent-foreground">Tip of the Day</h3>
              </div>
              <p className="text-accent-foreground/80">
                Apply fertilizers in early morning or evening to avoid nutrient loss from sun evaporation.
              </p>
            </div>

            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className="w-full bg-card rounded-2xl p-5 flex items-center gap-4 border border-border hover:border-primary/50 transition-all"
              >
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center">
                  {category.icon}
                </div>
                <div className="flex-1 text-left">
                  <h3 className="font-bold text-foreground text-lg">{category.title}</h3>
                  <p className="text-muted-foreground text-sm">{category.tips.length} tips</p>
                </div>
                <ChevronRight className="w-6 h-6 text-muted-foreground" />
              </button>
            ))}
          </div>
        ) : (
          /* Tips List */
          <div className="space-y-4">
            {selectedCategoryData?.tips.map((tip, index) => (
              <div
                key={index}
                className="bg-card rounded-2xl p-5 border border-border"
              >
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                    <span className="text-primary-foreground font-bold">{index + 1}</span>
                  </div>
                  <div>
                    <h3 className="font-bold text-foreground text-lg mb-2">{tip.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{tip.content}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
