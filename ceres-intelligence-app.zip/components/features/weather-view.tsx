"use client"

import { useApp } from "@/lib/app-context"
import { 
  ArrowLeft, 
  Cloud,
  Sun,
  CloudRain,
  Wind,
  Droplets,
  Thermometer,
  AlertTriangle,
  Calendar
} from "lucide-react"

interface WeatherViewProps {
  onBack: () => void
}

interface ForecastDay {
  day: string
  icon: React.ReactNode
  high: number
  low: number
  condition: string
  rainChance: number
}

export function WeatherView({ onBack }: WeatherViewProps) {
  const { farmerProfile } = useApp()

  const currentWeather = {
    temp: 28,
    condition: "Partly Cloudy",
    humidity: 65,
    wind: 12,
    rainChance: 20,
    feelsLike: 30
  }

  const forecast: ForecastDay[] = [
    { day: "Today", icon: <Sun className="w-8 h-8 text-accent" />, high: 32, low: 24, condition: "Sunny", rainChance: 10 },
    { day: "Tomorrow", icon: <Cloud className="w-8 h-8 text-muted-foreground" />, high: 30, low: 23, condition: "Cloudy", rainChance: 40 },
    { day: "Wed", icon: <CloudRain className="w-8 h-8 text-primary" />, high: 27, low: 22, condition: "Rain", rainChance: 80 },
    { day: "Thu", icon: <CloudRain className="w-8 h-8 text-primary" />, high: 26, low: 21, condition: "Rain", rainChance: 70 },
    { day: "Fri", icon: <Sun className="w-8 h-8 text-accent" />, high: 29, low: 22, condition: "Sunny", rainChance: 15 },
  ]

  const alerts = [
    {
      type: "warning",
      title: "Heavy Rain Expected",
      message: "Wednesday - Thursday. Consider delaying irrigation."
    }
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-b from-primary to-primary/80 px-6 pt-12 pb-8">
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={onBack}
            className="w-12 h-12 rounded-full bg-primary-foreground/20 flex items-center justify-center"
          >
            <ArrowLeft className="w-6 h-6 text-primary-foreground" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-primary-foreground">Weather</h1>
            <p className="text-primary-foreground/80">
              {farmerProfile?.location.village || "Your Location"}
            </p>
          </div>
        </div>

        {/* Current Weather */}
        <div className="text-center py-6">
          <Sun className="w-20 h-20 text-primary-foreground mx-auto mb-4" />
          <p className="text-6xl font-bold text-primary-foreground mb-2">
            {currentWeather.temp}°
          </p>
          <p className="text-xl text-primary-foreground/90">{currentWeather.condition}</p>
          <p className="text-primary-foreground/70 mt-1">
            Feels like {currentWeather.feelsLike}°
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-4 mt-4">
          <div className="bg-primary-foreground/10 rounded-xl p-4 text-center">
            <Droplets className="w-6 h-6 text-primary-foreground mx-auto mb-2" />
            <p className="text-primary-foreground font-semibold">{currentWeather.humidity}%</p>
            <p className="text-primary-foreground/70 text-sm">Humidity</p>
          </div>
          <div className="bg-primary-foreground/10 rounded-xl p-4 text-center">
            <Wind className="w-6 h-6 text-primary-foreground mx-auto mb-2" />
            <p className="text-primary-foreground font-semibold">{currentWeather.wind} km/h</p>
            <p className="text-primary-foreground/70 text-sm">Wind</p>
          </div>
          <div className="bg-primary-foreground/10 rounded-xl p-4 text-center">
            <CloudRain className="w-6 h-6 text-primary-foreground mx-auto mb-2" />
            <p className="text-primary-foreground font-semibold">{currentWeather.rainChance}%</p>
            <p className="text-primary-foreground/70 text-sm">Rain</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-6 space-y-6">
        {/* Alerts */}
        {alerts.length > 0 && (
          <div className="space-y-3">
            {alerts.map((alert, index) => (
              <div key={index} className="bg-moderate/20 rounded-2xl p-4 flex gap-4">
                <AlertTriangle className="w-6 h-6 text-moderate flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-moderate">{alert.title}</h4>
                  <p className="text-foreground/80 text-sm">{alert.message}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 5-Day Forecast */}
        <div className="bg-card rounded-2xl border border-border overflow-hidden">
          <div className="flex items-center gap-2 p-4 border-b border-border">
            <Calendar className="w-5 h-5 text-primary" />
            <h3 className="font-bold text-foreground">5-Day Forecast</h3>
          </div>
          <div className="divide-y divide-border">
            {forecast.map((day, index) => (
              <div key={index} className="flex items-center justify-between p-4">
                <div className="flex items-center gap-4 flex-1">
                  <span className="font-semibold text-foreground w-20">{day.day}</span>
                  {day.icon}
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1 text-primary">
                    <Droplets className="w-4 h-4" />
                    <span className="text-sm">{day.rainChance}%</span>
                  </div>
                  <div className="text-right">
                    <span className="font-semibold text-foreground">{day.high}°</span>
                    <span className="text-muted-foreground"> / {day.low}°</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Farming Advice */}
        <div className="bg-primary/10 rounded-2xl p-5">
          <h4 className="font-bold text-foreground mb-3">Weather-Based Advice</h4>
          <ul className="space-y-3 text-foreground/80">
            <li className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-primary mt-2" />
              <span>Good conditions for spraying today (low wind)</span>
            </li>
            <li className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-primary mt-2" />
              <span>Postpone irrigation - rain expected on Wednesday</span>
            </li>
            <li className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-primary mt-2" />
              <span>Harvest any mature crops before Wednesday</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}
