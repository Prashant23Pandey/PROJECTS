"use client"

import { 
  ArrowLeft, 
  Sprout,
  Flower2,
  Wheat,
  Check,
  Lightbulb
} from "lucide-react"

interface CropTrackerProps {
  onBack: () => void
}

interface CropStage {
  name: string
  description: string
  duration: string
  tips: string[]
  isComplete: boolean
  isCurrent: boolean
}

export function CropTracker({ onBack }: CropTrackerProps) {
  const stages: CropStage[] = [
    {
      name: "Seed Stage",
      description: "Seeds planted and germinating",
      duration: "Week 1-2",
      tips: ["Keep soil moist", "Maintain temperature 25-30°C", "Check for proper drainage"],
      isComplete: true,
      isCurrent: false
    },
    {
      name: "Seedling Stage",
      description: "Young plants emerging",
      duration: "Week 2-4",
      tips: ["Apply light fertilizer", "Protect from pests", "Ensure adequate sunlight"],
      isComplete: true,
      isCurrent: false
    },
    {
      name: "Vegetative Stage",
      description: "Plants growing and developing leaves",
      duration: "Week 4-8",
      tips: ["Regular watering", "Apply nitrogen fertilizer", "Monitor for diseases"],
      isComplete: false,
      isCurrent: true
    },
    {
      name: "Flowering Stage",
      description: "Plants producing flowers",
      duration: "Week 8-12",
      tips: ["Reduce nitrogen", "Increase phosphorus", "Protect from wind"],
      isComplete: false,
      isCurrent: false
    },
    {
      name: "Harvest Stage",
      description: "Crops ready for harvesting",
      duration: "Week 12-16",
      tips: ["Check moisture content", "Harvest in dry weather", "Proper storage"],
      isComplete: false,
      isCurrent: false
    },
  ]

  const progress = (stages.filter(s => s.isComplete).length / stages.length) * 100

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-primary px-6 pt-12 pb-6">
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={onBack}
            className="w-12 h-12 rounded-full bg-primary-foreground/20 flex items-center justify-center"
          >
            <ArrowLeft className="w-6 h-6 text-primary-foreground" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-primary-foreground">Crop Tracker</h1>
            <p className="text-primary-foreground/80">Rice - Season 2024</p>
          </div>
        </div>

        {/* Progress */}
        <div className="bg-primary-foreground/10 rounded-2xl p-5">
          <div className="flex justify-between items-center mb-3">
            <span className="text-primary-foreground font-semibold">Growth Progress</span>
            <span className="text-primary-foreground font-bold">{Math.round(progress)}%</span>
          </div>
          <div className="h-3 bg-primary-foreground/20 rounded-full overflow-hidden">
            <div 
              className="h-full bg-primary-foreground rounded-full transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Timeline */}
      <div className="px-6 py-6">
        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-border" />

          <div className="space-y-6">
            {stages.map((stage, index) => (
              <div key={index} className="relative pl-16">
                {/* Timeline dot */}
                <div className={`absolute left-0 w-12 h-12 rounded-full flex items-center justify-center ${
                  stage.isComplete 
                    ? "bg-good text-primary-foreground" 
                    : stage.isCurrent 
                      ? "bg-primary text-primary-foreground ring-4 ring-primary/20"
                      : "bg-muted text-muted-foreground"
                }`}>
                  {stage.isComplete ? (
                    <Check className="w-6 h-6" />
                  ) : index === 0 ? (
                    <Sprout className="w-6 h-6" />
                  ) : index === 3 ? (
                    <Flower2 className="w-6 h-6" />
                  ) : index === 4 ? (
                    <Wheat className="w-6 h-6" />
                  ) : (
                    <Sprout className="w-6 h-6" />
                  )}
                </div>

                {/* Content */}
                <div className={`bg-card rounded-2xl p-5 border ${
                  stage.isCurrent ? "border-primary border-2" : "border-border"
                }`}>
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className={`font-bold text-lg ${
                        stage.isCurrent ? "text-primary" : "text-foreground"
                      }`}>
                        {stage.name}
                      </h3>
                      <p className="text-muted-foreground text-sm">{stage.description}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      stage.isComplete 
                        ? "bg-good/20 text-good" 
                        : stage.isCurrent 
                          ? "bg-primary/20 text-primary"
                          : "bg-muted text-muted-foreground"
                    }`}>
                      {stage.duration}
                    </span>
                  </div>

                  {stage.isCurrent && (
                    <div className="mt-4 bg-primary/5 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Lightbulb className="w-5 h-5 text-primary" />
                        <span className="font-semibold text-primary">Current Stage Tips</span>
                      </div>
                      <ul className="space-y-2">
                        {stage.tips.map((tip, tipIndex) => (
                          <li key={tipIndex} className="flex items-start gap-2 text-foreground/80 text-sm">
                            <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
                            <span>{tip}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
