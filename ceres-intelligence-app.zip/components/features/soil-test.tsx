"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { 
  Sprout, 
  ArrowLeft, 
  Thermometer,
  Droplets,
  Leaf,
  Activity,
  Info
} from "lucide-react"

interface SoilTestProps {
  onBack: () => void
}

interface SoilMetric {
  label: string
  value: number
  unit: string
  status: "good" | "moderate" | "poor"
  icon: React.ReactNode
  description: string
}

export function SoilTest({ onBack }: SoilTestProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [hasData, setHasData] = useState(true)

  const metrics: SoilMetric[] = [
    {
      label: "Moisture Level",
      value: 72,
      unit: "%",
      status: "good",
      icon: <Droplets className="w-6 h-6" />,
      description: "Good moisture for crops"
    },
    {
      label: "Temperature",
      value: 24,
      unit: "°C",
      status: "good",
      icon: <Thermometer className="w-6 h-6" />,
      description: "Ideal growing temperature"
    },
    {
      label: "Nitrogen (N)",
      value: 45,
      unit: "kg/ha",
      status: "moderate",
      icon: <Leaf className="w-6 h-6" />,
      description: "Consider adding fertilizer"
    },
    {
      label: "Phosphorus (P)",
      value: 32,
      unit: "kg/ha",
      status: "good",
      icon: <Activity className="w-6 h-6" />,
      description: "Adequate levels"
    },
    {
      label: "Potassium (K)",
      value: 18,
      unit: "kg/ha",
      status: "poor",
      icon: <Sprout className="w-6 h-6" />,
      description: "Needs attention"
    },
  ]

  const overallScore = 75
  const overallStatus = overallScore >= 70 ? "good" : overallScore >= 50 ? "moderate" : "poor"

  const handleRefresh = () => {
    setIsLoading(true)
    setTimeout(() => {
      setIsLoading(false)
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary px-6 pt-12 pb-6">
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={onBack}
            className="w-12 h-12 rounded-full bg-primary-foreground/20 flex items-center justify-center"
          >
            <ArrowLeft className="w-6 h-6 text-primary-foreground" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-primary-foreground">Test Your Soil</h1>
            <p className="text-primary-foreground/80">Check soil health & nutrients</p>
          </div>
        </div>

        {/* Overall Score */}
        <div className="bg-primary-foreground/10 rounded-2xl p-5 flex items-center gap-5">
          <div className={`w-20 h-20 rounded-full flex items-center justify-center ${
            overallStatus === "good" ? "bg-good" :
            overallStatus === "moderate" ? "bg-moderate" :
            "bg-poor"
          }`}>
            <span className="text-3xl font-bold text-primary-foreground">{overallScore}</span>
          </div>
          <div>
            <p className="text-primary-foreground font-bold text-xl">Soil Health Score</p>
            <p className="text-primary-foreground/80">
              {overallStatus === "good" ? "Your soil is healthy!" :
               overallStatus === "moderate" ? "Some attention needed" :
               "Needs improvement"}
            </p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-6 space-y-6">
        {/* Metrics Grid */}
        <div className="space-y-4">
          {metrics.map((metric, index) => (
            <div 
              key={index}
              className="bg-card rounded-2xl p-5 border border-border"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    metric.status === "good" ? "bg-good/20 text-good" :
                    metric.status === "moderate" ? "bg-moderate/20 text-moderate" :
                    "bg-poor/20 text-poor"
                  }`}>
                    {metric.icon}
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground text-lg">{metric.label}</h3>
                    <p className="text-muted-foreground text-sm">{metric.description}</p>
                  </div>
                </div>
              </div>
              
              {/* Progress bar */}
              <div className="mt-4">
                <div className="flex justify-between mb-2">
                  <span className={`text-2xl font-bold ${
                    metric.status === "good" ? "text-good" :
                    metric.status === "moderate" ? "text-moderate" :
                    "text-poor"
                  }`}>
                    {metric.value}{metric.unit}
                  </span>
                  <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                    metric.status === "good" ? "bg-good/20 text-good" :
                    metric.status === "moderate" ? "bg-moderate/20 text-moderate" :
                    "bg-poor/20 text-poor"
                  }`}>
                    {metric.status === "good" ? "Good" :
                     metric.status === "moderate" ? "Moderate" : "Poor"}
                  </span>
                </div>
                <div className="h-3 bg-muted rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all ${
                      metric.status === "good" ? "bg-good" :
                      metric.status === "moderate" ? "bg-moderate" :
                      "bg-poor"
                    }`}
                    style={{ width: `${metric.value}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Info Card */}
        <div className="bg-accent/30 rounded-2xl p-5 flex gap-4">
          <Info className="w-6 h-6 text-accent-foreground flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="font-semibold text-accent-foreground mb-1">Tip</h4>
            <p className="text-accent-foreground/80 text-sm">
              Based on your soil analysis, consider adding potassium-rich fertilizers to improve crop yield.
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-3 pb-6">
          <Button 
            size="lg" 
            className="w-full h-14 text-lg"
            onClick={handleRefresh}
            disabled={isLoading}
          >
            {isLoading ? "Refreshing..." : "Refresh Readings"}
          </Button>
          <Button 
            variant="outline" 
            size="lg" 
            className="w-full h-14 text-lg"
          >
            Get Detailed Report
          </Button>
        </div>
      </div>
    </div>
  )
}
