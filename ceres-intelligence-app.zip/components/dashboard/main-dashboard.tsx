"use client"

import { useApp } from "@/lib/app-context"
import { 
  Sprout, 
  Droplets, 
  Bug, 
  Leaf, 
  Camera,
  MessageCircle,
  Cloud,
  Beaker,
  TrendingUp,
  AlertTriangle,
  DollarSign,
  BookOpen,
  Bell,
  User,
  ChevronRight
} from "lucide-react"

interface FeatureCardProps {
  icon: React.ReactNode
  title: string
  description: string
  status?: "good" | "moderate" | "poor"
  statusText?: string
  onClick: () => void
}

function FeatureCard({ icon, title, description, status, statusText, onClick }: FeatureCardProps) {
  return (
    <button 
      onClick={onClick}
      className="w-full bg-card rounded-2xl p-5 flex items-center gap-4 shadow-sm border border-border hover:border-primary/50 transition-all active:scale-[0.98]"
    >
      <div className="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
        {icon}
      </div>
      <div className="flex-1 text-left">
        <h3 className="text-lg font-bold text-foreground">{title}</h3>
        <p className="text-muted-foreground text-sm">{description}</p>
        {status && statusText && (
          <span className={`inline-flex items-center mt-2 px-3 py-1 rounded-full text-sm font-semibold ${
            status === "good" ? "bg-good/20 text-good" :
            status === "moderate" ? "bg-moderate/20 text-moderate" :
            "bg-poor/20 text-poor"
          }`}>
            {statusText}
          </span>
        )}
      </div>
      <ChevronRight className="w-6 h-6 text-muted-foreground" />
    </button>
  )
}

function LargeFeatureCard({ icon, title, description, onClick }: Omit<FeatureCardProps, "status" | "statusText">) {
  return (
    <button 
      onClick={onClick}
      className="w-full bg-primary rounded-2xl p-6 text-left shadow-lg hover:opacity-95 transition-all active:scale-[0.98]"
    >
      <div className="w-16 h-16 rounded-xl bg-primary-foreground/20 flex items-center justify-center mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-bold text-primary-foreground mb-1">{title}</h3>
      <p className="text-primary-foreground/80">{description}</p>
    </button>
  )
}

export function MainDashboard() {
  const { farmerProfile, setCurrentView } = useApp()

  const features = [
    {
      id: "soil-test",
      icon: <Sprout className="w-8 h-8 text-primary" />,
      title: "Test Your Soil",
      description: "Check soil health & nutrients",
      status: "good" as const,
      statusText: "Healthy"
    },
    {
      id: "moisture",
      icon: <Droplets className="w-8 h-8 text-primary" />,
      title: "Soil Moisture",
      description: "Monitor water levels",
      status: "moderate" as const,
      statusText: "72% Level"
    },
    {
      id: "pesticide",
      icon: <Bug className="w-8 h-8 text-primary" />,
      title: "Pesticide Check",
      description: "Detect harmful chemicals",
    },
    {
      id: "leaf-scanner",
      icon: <Leaf className="w-8 h-8 text-primary" />,
      title: "Leaf Health",
      description: "Scan for diseases",
    },
    {
      id: "crop-id",
      icon: <Camera className="w-8 h-8 text-primary" />,
      title: "Identify Crop",
      description: "Upload plant photo",
    },
    {
      id: "weather",
      icon: <Cloud className="w-8 h-8 text-primary" />,
      title: "Weather",
      description: "Local forecast & alerts",
    },
    {
      id: "fertilizer",
      icon: <Beaker className="w-8 h-8 text-primary" />,
      title: "Fertilizer Advice",
      description: "Get nutrition tips",
    },
    {
      id: "growth",
      icon: <TrendingUp className="w-8 h-8 text-primary" />,
      title: "Crop Growth",
      description: "Track crop stages",
    },
    {
      id: "pest-warning",
      icon: <AlertTriangle className="w-8 h-8 text-primary" />,
      title: "Pest Warning",
      description: "Early detection alerts",
    },
    {
      id: "market",
      icon: <DollarSign className="w-8 h-8 text-primary" />,
      title: "Market Prices",
      description: "Current crop rates",
    },
    {
      id: "tips",
      icon: <BookOpen className="w-8 h-8 text-primary" />,
      title: "Farming Tips",
      description: "Daily knowledge",
    },
  ]

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-primary px-6 pt-12 pb-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-primary-foreground/20 flex items-center justify-center">
              <Sprout className="w-7 h-7 text-primary-foreground" />
            </div>
            <div>
              <p className="text-primary-foreground/80 text-sm">Welcome back,</p>
              <h1 className="text-xl font-bold text-primary-foreground">
                {farmerProfile?.name || "Farmer"}
              </h1>
            </div>
          </div>
          <div className="flex gap-3">
            <button className="w-12 h-12 rounded-full bg-primary-foreground/20 flex items-center justify-center">
              <Bell className="w-6 h-6 text-primary-foreground" />
            </button>
            <button className="w-12 h-12 rounded-full bg-primary-foreground/20 flex items-center justify-center">
              <User className="w-6 h-6 text-primary-foreground" />
            </button>
          </div>
        </div>

        {/* Farm Health Score */}
        <div className="bg-primary-foreground/10 rounded-2xl p-4 flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-primary-foreground flex items-center justify-center">
            <span className="text-2xl font-bold text-primary">78</span>
          </div>
          <div>
            <p className="text-primary-foreground font-semibold text-lg">Farm Health Score</p>
            <p className="text-primary-foreground/80 text-sm">Your farm is doing well!</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-6 space-y-6">
        {/* AI Assistant Card */}
        <LargeFeatureCard
          icon={<MessageCircle className="w-8 h-8 text-primary-foreground" />}
          title="AI Farming Assistant"
          description="Ask any farming question"
          onClick={() => setCurrentView("assistant")}
        />

        {/* Feature Grid */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-foreground">Farm Tools</h2>
          {features.map((feature) => (
            <FeatureCard
              key={feature.id}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
              status={feature.status}
              statusText={feature.statusText}
              onClick={() => setCurrentView(feature.id)}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
