"use client"

import { useApp } from "@/lib/app-context"
import { 
  Home, 
  Leaf, 
  MessageCircle,
  Cloud,
  User
} from "lucide-react"

export function BottomNav() {
  const { currentView, setCurrentView } = useApp()

  const navItems = [
    { id: "dashboard", icon: Home, label: "Home" },
    { id: "leaf-scanner", icon: Leaf, label: "Scan" },
    { id: "assistant", icon: MessageCircle, label: "Ask AI" },
    { id: "weather", icon: Cloud, label: "Weather" },
    { id: "profile", icon: User, label: "Profile" },
  ]

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border px-4 pb-6 pt-3 z-50">
      <div className="flex justify-around items-center max-w-lg mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = currentView === item.id || 
            (item.id === "dashboard" && !["dashboard", "leaf-scanner", "assistant", "weather", "profile"].includes(currentView) && currentView !== "assistant")
          
          return (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id)}
              className={`flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-colors ${
                isActive 
                  ? "text-primary" 
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${
                isActive ? "bg-primary/10" : ""
              }`}>
                <Icon className={`w-6 h-6 ${isActive ? "text-primary" : ""}`} />
              </div>
              <span className={`text-xs font-medium ${isActive ? "text-primary" : ""}`}>
                {item.label}
              </span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
