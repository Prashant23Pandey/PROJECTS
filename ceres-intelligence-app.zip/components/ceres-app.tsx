"use client"

import { useApp } from "@/lib/app-context"
import { OnboardingFlow } from "@/components/onboarding/onboarding-flow"
import { MainDashboard } from "@/components/dashboard/main-dashboard"
import { BottomNav } from "@/components/navigation/bottom-nav"
import { SoilTest } from "@/components/features/soil-test"
import { LeafScanner } from "@/components/features/leaf-scanner"
import { WeatherView } from "@/components/features/weather-view"
import { AIAssistant } from "@/components/features/ai-assistant"
import { MarketPrices } from "@/components/features/market-prices"
import { CropTracker } from "@/components/features/crop-tracker"
import { FarmingTips } from "@/components/features/farming-tips"

export function CeresApp() {
  const { isOnboarded, currentView, setCurrentView } = useApp()

  const handleBack = () => setCurrentView("dashboard")

  if (!isOnboarded) {
    return <OnboardingFlow />
  }

  const renderView = () => {
    switch (currentView) {
      case "soil-test":
        return <SoilTest onBack={handleBack} />
      case "leaf-scanner":
        return <LeafScanner onBack={handleBack} />
      case "weather":
        return <WeatherView onBack={handleBack} />
      case "assistant":
        return <AIAssistant onBack={handleBack} />
      case "market":
        return <MarketPrices onBack={handleBack} />
      case "growth":
        return <CropTracker onBack={handleBack} />
      case "tips":
        return <FarmingTips onBack={handleBack} />
      case "dashboard":
      default:
        return <MainDashboard />
    }
  }

  // Don't show bottom nav on AI assistant (full screen chat)
  const showBottomNav = currentView !== "assistant"

  return (
    <div className="max-w-lg mx-auto bg-background min-h-screen relative">
      {renderView()}
      {showBottomNav && <BottomNav />}
    </div>
  )
}
