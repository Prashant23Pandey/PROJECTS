"use client"

import { createContext, useContext, useState, ReactNode } from "react"

export interface FarmerProfile {
  name: string
  phone: string
  language: string
  location: {
    village: string
    district: string
    state: string
  }
  experience: "beginner" | "2+" | "5+" | "10+"
  crops?: string[]
  farmSize?: string
  soilType?: string
  irrigationMethod?: string
}

interface AppContextType {
  isOnboarded: boolean
  setIsOnboarded: (value: boolean) => void
  farmerProfile: FarmerProfile | null
  setFarmerProfile: (profile: FarmerProfile) => void
  currentView: string
  setCurrentView: (view: string) => void
}

const AppContext = createContext<AppContextType | undefined>(undefined)

export function AppProvider({ children }: { children: ReactNode }) {
  const [isOnboarded, setIsOnboarded] = useState(false)
  const [farmerProfile, setFarmerProfile] = useState<FarmerProfile | null>(null)
  const [currentView, setCurrentView] = useState("dashboard")

  return (
    <AppContext.Provider
      value={{
        isOnboarded,
        setIsOnboarded,
        farmerProfile,
        setFarmerProfile,
        currentView,
        setCurrentView,
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const context = useContext(AppContext)
  if (context === undefined) {
    throw new Error("useApp must be used within an AppProvider")
  }
  return context
}
